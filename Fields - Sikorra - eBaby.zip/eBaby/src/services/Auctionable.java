package services;

public interface Auctionable {
	public void handleAuctionEvents(long now);
}
