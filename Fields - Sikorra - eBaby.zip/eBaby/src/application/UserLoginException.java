package application;

public class UserLoginException extends RuntimeException {
}
