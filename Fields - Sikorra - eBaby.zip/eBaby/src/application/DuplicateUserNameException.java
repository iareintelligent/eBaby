package application;

public class DuplicateUserNameException extends RuntimeException {
}
