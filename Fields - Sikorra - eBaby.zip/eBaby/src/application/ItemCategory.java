package application;

public enum ItemCategory {
    OTHER, DOWNLOADABLE_SOFTWARE, CAR;
}
