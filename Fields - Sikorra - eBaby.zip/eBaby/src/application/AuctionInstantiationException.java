package application;

public class AuctionInstantiationException extends RuntimeException {

}
