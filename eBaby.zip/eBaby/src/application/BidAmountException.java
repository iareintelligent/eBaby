package application;

public class BidAmountException extends RuntimeException {

}
