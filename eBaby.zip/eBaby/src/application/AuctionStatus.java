package application;

public enum AuctionStatus {
    CREATED,STARTED,CLOSED;
}
