package application;

public class DontSellYourselfShortException extends RuntimeException {
}
