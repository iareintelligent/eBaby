package application;

public class AuctionStatusException extends RuntimeException{
}
