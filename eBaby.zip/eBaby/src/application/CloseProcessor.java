package application;

public interface CloseProcessor {

    public void process();
}
