package services;

public interface Hours {
	public boolean isOffHours();
}
